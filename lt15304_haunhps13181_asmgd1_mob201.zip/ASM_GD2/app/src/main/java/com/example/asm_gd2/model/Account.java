package com.example.asm_gd2.model;

public class Account {
    public String username;
    public String password;

    public Account() {
    }

    public Account(String username, String password) {
        this.username = username;
        this.password = password;
    }
}
